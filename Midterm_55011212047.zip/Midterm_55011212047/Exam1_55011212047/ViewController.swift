//
//  ViewController.swift
//  Exam1_55011212047
//
//  Created by student on 10/10/14.
//  Copyright (c) 2014 student. All rights reserved.
//

/*import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
*/

//********************************************

//
//  ViewController.swift
//  Exam1_55011212047
//
//  Created by student on 10/10/14.
//  Copyright (c) 2014 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController{
    
    let cellIdentifier = " celldentifie "
    var tableData = ["Bus","Helicopter"]
    
    @IBOutlet var N: UITableView!
    @IBOutlet weak var V: UITextField!
    @IBOutlet weak var P: UITextField!
    @IBOutlet weak var To_out: UITextField!
    
    @IBAction func To(sender: AnyObject)
    {
        
    }
    
    @IBAction func Pr(sender: AnyObject)
    {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

